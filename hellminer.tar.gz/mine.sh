./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RARNZ6LoxcvsUgVHM1f2MDmnVfzDFxqV1R.hellminer -p x --cpu 8
